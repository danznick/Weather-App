//
//  Constant.swift
//  Weather
//
//  Created by Daniel Gomes on 27/03/20.
//  Copyright © 2020 Daniel Gomes. All rights reserved.
//

import Foundation

let fileManager = FileManager.default
let feature = "Feature"
